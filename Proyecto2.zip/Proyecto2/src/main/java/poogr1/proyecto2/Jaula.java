/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poogr1.proyecto2;

import java.util.List;

/**
 *
 * @author Xiomara
 */
public class Jaula {
    private String operacion;
    private List<String> jaulas;
    
    public Jaula(String pOperacion, List<String> pJaulas){
        setOperacion(pOperacion);
        setJaulas(pJaulas);
    }
    
    public void setOperacion(String pOperacion){
        operacion = pOperacion;
    }
    
    public void setJaulas(List<String> pJaulas){
        jaulas = pJaulas;
    }
    
    public String getOperacion(){
        return operacion;
    }
    
    public List<String> getJaulas(){
        return jaulas;
    }
}
