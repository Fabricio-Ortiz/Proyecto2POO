/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poogr1.proyecto2;

import java.util.ArrayList;
import java.util.List;

public class Partida {
    private String dificultad;
    private List<Jaula> jugadas;
    private List<String> constantes;
    
    public Partida(String pDificultad, List<String> pConstantes){
        jugadas = new ArrayList<>();
        setDificultad(pDificultad);
        setConstantes(pConstantes);
    }
    
    public void setDificultad(String pDificultad){
        dificultad = pDificultad;
    }
    
    public void setConstantes(List<String> pConstantes){
        constantes = pConstantes;
    }
    
    public String getDificultad(){
        return dificultad;
    }
    
    public int contarOperacion(String operacion){
        int indice = 0;
        int contador = 1;
        for (Jaula ind:jugadas){
            if(ind.getOperacion().equals(operacion)){
                contador ++;
            }
            indice ++;
        }
        return contador;
    }
    
    public void agregarJugada(Jaula obj){
        int conteo = contarOperacion(obj.getOperacion());
        if(conteo > 1){
            obj.setOperacion(obj.getOperacion()+ "(" + conteo + ")");
        }
        jugadas.add(obj);
    }
    
    public List<Jaula> getJaulas(){
        return jugadas;
    }
    
    public List<String> getConstantes(){
        return constantes;
    }
}
