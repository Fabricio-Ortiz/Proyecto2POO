package poogr1.proyecto2;

import java.util.ArrayList;
import java.util.List;

public class MovimientosBorrados {
    private List<Movimiento> movimientos;
    
    public MovimientosBorrados(){
        movimientos = new ArrayList<>();
    }
    /**
     * Agrega un movimiento a la lista
     * @param pMovimiento movimiento a agregar
     */
    public void agregarMovimiento(Movimiento pMovimiento){
        movimientos.add(pMovimiento);
    }
    /**
     * Busca el movimiento en la lista
     * @param pValorCelda valor de celda del movimiento
     * @param pPosicionCelda posicion de celda del moviminto
     * @return el indice de la lista del movimiento encontrado
     */
    public int buscarMovimiento(int pValorCelda, String pPosicionCelda){
        int indice = 0;
        for (Movimiento ind:movimientos){
            if(ind.getPosicionCelda().equals(pPosicionCelda) && ind.getValorCelda() == pValorCelda){
                return indice;
            }
            indice ++;
        }
        return -1;
    }
    /**
     * Borra el primer movimiento de la lista y lo retorna
     * @return el primer movimiento de la lista
     */
    public Movimiento rehacerJugada(){
        Movimiento movimientoBorrado = movimientos.get(0);
        movimientos.remove(0);
        return movimientoBorrado;
    }
}