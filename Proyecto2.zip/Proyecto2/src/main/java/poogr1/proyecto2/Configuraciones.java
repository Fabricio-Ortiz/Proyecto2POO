/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poogr1.proyecto2;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

/**
 *
 * @author Xiomara
 */
public class Configuraciones {
    private List<String> configuracion;
    
    public Configuraciones(List<String> pConfiguracion){
        setConfiguracion(pConfiguracion);
    }
    
    public void setConfiguracion(List<String> pConfiguracion){
        configuracion = pConfiguracion;
    }
    
    public List<String> getConfiguracion(){
        return configuracion;
    }
    /**
     * Guarda la configuracion en un archivo .dat
     * @param pConfiguracion la configuracion a guardar
     * @throws IOException 
     */
    public void guardarArchivo(List<String> pConfiguracion) throws IOException{
        File file = new File("C:\\Users\\Xiomara\\Documents\\NetBeansProjects\\Proyecto2", "configuracion.dat");
        if (!file.exists()) {
                file.createNewFile();
            }
        BufferedWriter fichero = null;
        fichero = new BufferedWriter (new FileWriter ("configuracion.dat"));
        for(String ind: pConfiguracion){
            fichero.write(ind + "\n");
        }
        fichero.close();
    }
}
