/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package poogr1.proyecto2;

import java.awt.Color;
import java.util.List;

/**
 *
 * @author Xiomara
 */
public class JuegoIzq extends javax.swing.JFrame {

    /**
     * Creates new form JuegoIzq
     */
    public String valorCelda = "";
    public Configuraciones config;
    public String posicion;
    public List<Partida> partidasElegibles;
    public Partida partidaElegida;
    public int Elegida;
    public MovimientosHechos movimientosHechos;
    public MovimientosBorrados movimientosBorrados;
    public JuegoIzq(MovimientosHechos pMovimientosHechos, MovimientosBorrados pMovimientosBorrados, 
            List<Partida> pPartidasElegibles, Partida pPartidaElegida, int pElegida, 
            Configuraciones pConfig) {
        initComponents();
        setMovimientosHechos(pMovimientosHechos);
        setMovimientosBorrados(pMovimientosBorrados);
        setPartidaElegida(pPartidaElegida);
        setElegida(pElegida);
        setPartidasElegibles(pPartidasElegibles);
        setConfig(pConfig);
    }
    
    public void setPartidasElegibles(List<Partida> pPartidasElegibles){
        partidasElegibles = pPartidasElegibles;
    }
    
    public void setElegida(int pElegida){
        Elegida = pElegida;
    }
    
    public void setPartidaElegida(Partida pPartidaElegida){
        partidaElegida = pPartidaElegida;
    }
    
    public void setConfig(Configuraciones pConfig){
        config = pConfig;
    }
    
    public void setMovimientosHechos(MovimientosHechos pMovimientosHechos){
        movimientosHechos = pMovimientosHechos;
    }
    
    public void setMovimientosBorrados(MovimientosBorrados pMovimientosBorrados){
        movimientosBorrados = pMovimientosBorrados;
    }
    
    public MovimientosHechos getMovimientosHechos(){
        return movimientosHechos;
    }
    
    public MovimientosBorrados getMovimientosBorrados(){
        return movimientosBorrados;
    }
    
    public List<Partida> getPartidasElegibles(){
        return partidasElegibles;
    }
    
    public int getElegida(){
        return Elegida;
    }
    
    public Partida getPartidaElegida(){
        return partidaElegida;
    }
    
    public Configuraciones getConfig(){
        return config;
    }
    /**
     * Toma la partida elegida y 
     * @param pPartida 
     */
    public void pintarOperaciones(Partida pPartida){
        List<Jaula> kenKen = pPartida.getJaulas();
        for(Jaula ind: kenKen){
            String operacion = ind.getOperacion();
            List<String> posiciones = ind.getJaulas();            
            for(String jnd: posiciones){
                elegirCeldaOp(operacion, jnd);
            }
        }
        List<String> constantes = partidaElegida.getConstantes();
        for(int j = 0; j < constantes.size(); j++){
            String numero = constantes.get(j).substring(1, 2);
            String celda = constantes.get(j).substring(2, 8);
        }
    }
    
    /**
     * Elige la celda donde se muestra la operacion en la interfaz
     * @param operacion la operacion a mostrar
     * @param posicion la posicion de dicha operacion
     */
    public void elegirCeldaOp(String operacion, String posicion){
        switch(posicion){
            case " (1, 1)" -> {
                lab1_1.setText(operacion);
            }
            case " (1, 2)" -> {
                lab1_2.setText(operacion);
            }
            case " (1, 3)" -> {
                lab1_3.setText(operacion);
            }
            case " (1, 4)" -> {
                lab1_4.setText(operacion);
            }
            case " (1, 5)" -> {
                lab1_5.setText(operacion);
            }
            case " (1, 6)" -> {
                lab1_6.setText(operacion);
            }
            case " (2, 1)" -> {
                lab2_1.setText(operacion);
            }
            case " (2, 2)" -> {
                lab2_2.setText(operacion);
            }
            case " (2, 3)" -> {
                lab2_3.setText(operacion);
            }
            case " (2, 4)" -> {
                lab2_4.setText(operacion);
            }
            case " (2, 5)" -> {
                lab2_5.setText(operacion);
            }
            case " (2, 6)" -> {
                lab2_6.setText(operacion);
            }
            case " (3, 1)" -> {
                lab3_1.setText(operacion);
            }
            case " (3, 2)" -> {
                lab3_2.setText(operacion);
            }
            case " (3, 3)" -> {
                lab3_3.setText(operacion);
            }
            case " (3, 4)" -> {
                lab3_4.setText(operacion);
            }
            case " (3, 5)" -> {
                lab3_5.setText(operacion);
            }
            case " (3, 6)" -> {
                lab3_6.setText(operacion);
            }
            case " (4, 1)" -> {
                lab4_1.setText(operacion);
            }
            case " (4, 2)" -> {
                lab4_2.setText(operacion);
            }
            case " (4, 3)" -> {
                lab4_3.setText(operacion);
            }
            case " (4, 4)" -> {
                lab4_4.setText(operacion);
            }
            case " (4, 5)" -> {
                lab4_5.setText(operacion);
            }
            case " (4, 6)" -> {
                lab4_6.setText(operacion);
            }
            case " (5, 1)" -> {
                lab5_1.setText(operacion);
            }
            case " (5, 2)" -> {
                lab5_2.setText(operacion);
            }
            case " (5, 3)" -> {
                lab5_3.setText(operacion);
            }
            case " (5, 4)" -> {
                lab5_4.setText(operacion);
            }
            case " (5, 5)" -> {
                lab5_5.setText(operacion);
            }
            case " (5, 6)" -> {
                lab5_6.setText(operacion);
            }
            case " (6, 1)" -> {
                lab6_1.setText(operacion);
            }
            case " (6, 2)" -> {
                lab6_2.setText(operacion);
            }
            case " (6, 3)" -> {
                lab6_3.setText(operacion);
            }
            case " (6, 4)" -> {
                lab6_4.setText(operacion);
            }
            case " (6, 5)" -> {
                lab6_5.setText(operacion);
            }
            case " (6, 6)" -> {
                lab6_6.setText(operacion);
            }
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    public boolean comprobarJuego(String operacion, List<String> posicion){
        int resultado = Integer.parseInt(operacion.substring(0, 1));
        String op;
        String numero1 = null;
        String numero2 = null;
        if(operacion.length() == 1){
            op = "=";
        }
        else{
            op = operacion.substring(1, 2);
        }
        if("/".equals(op) || "-".equals(op) || "=".equals(op)){
        switch(posicion.get(0)){
            case " (1, 1)" -> {
            numero1 = lab1_1.getText();
        }
        case " (1, 2)" -> {
            numero1 = lab1_2.getText();
        }
        case " (1, 3)" -> {
            numero1 = lab1_3.getText();
        }
        case " (1, 4)" -> {
            numero1 = lab1_4.getText();
        }
        case " (1, 5)" -> {
            numero1 = lab1_5.getText();
        }
        case " (1, 6)" -> {
            numero1 = lab1_6.getText();
        }
        case " (2, 1)" -> {
            numero1 = lab2_1.getText();
        }
        case " (2, 2)" -> {
            numero1 = lab2_2.getText();
        }
        case " (2, 3)" -> {
            numero1 = lab2_3.getText();
        }
        case " (2, 4)" -> {
            numero1 = lab2_4.getText();
        }
        case " (2, 5)" -> {
            numero1 = lab2_5.getText();
        }
        case " (2, 6)" -> {
            numero1 = lab2_6.getText();
        }
        case " (3, 1)" -> {
            numero1 = lab3_1.getText();
        }
        case " (3, 2)" -> {
            numero1 = lab3_2.getText();
        }
        case " (3, 3)" -> {
            numero1 = lab3_3.getText();
        }
        case " (3, 4)" -> {
            numero1 = lab3_4.getText();
        }
        case " (3, 5)" -> {
            numero1 = lab3_5.getText();
        }
        case " (3, 6)" -> {
            numero1 = lab3_6.getText();
        }
        case " (4, 1)" -> {
            numero1 = lab4_1.getText();
        }
        case " (4, 2)" -> {
            numero1 = lab4_2.getText();
        }
        case " (4, 3)" -> {
            numero1 = lab4_3.getText();
        }
        case " (4, 4)" -> {
            numero1 = lab4_4.getText();
        }
        case " (4, 5)" -> {
            numero1 = lab4_5.getText();
        }
        case " (4, 6)" -> {
            numero1 = lab4_6.getText();
        }
        case " (5, 1)" -> {
            numero1 = lab5_1.getText();
        }
        case " (5, 2)" -> {
            numero1 = lab5_2.getText();
        }
        case " (5, 3)" -> {
            numero1 = lab5_3.getText();
        }
        case " (5, 4)" -> {
            numero1 = lab5_4.getText();
        }
        case " (5, 5)" -> {
            numero1 = lab5_5.getText();
        }
        case " (5, 6)" -> {
            numero1 = lab5_6.getText();
        }
        case " (6, 1)" -> {
            numero1 = lab6_1.getText();
        }
        case " (6, 2)" -> {
            numero1 = lab6_2.getText();
        }
        case " (6, 3)" -> {
            numero1 = lab6_3.getText();
        }
        case " (6, 4)" -> {
            numero1 = lab6_4.getText();
        }
        case " (6, 5)" -> {
            numero1 = lab6_5.getText();
        }
        case " (6, 6)" -> {
            numero1 = lab6_6.getText();
        }
        }
        }
        if("/".equals(op) || "-".equals(op)){
            switch(posicion.get(0)){
            case " (1, 1)" -> {
            numero2 = lab1_1.getText();
        }
        case " (1, 2)" -> {
            numero2 = lab1_2.getText();
        }
        case " (1, 3)" -> {
            numero2 = lab1_3.getText();
        }
        case " (1, 4)" -> {
            numero2 = lab1_4.getText();
        }
        case " (1, 5)" -> {
            numero2 = lab1_5.getText();
        }
        case " (1, 6)" -> {
            numero2 = lab1_6.getText();
        }
        case " (2, 1)" -> {
            numero2 = lab2_1.getText();
        }
        case " (2, 2)" -> {
            numero2 = lab2_2.getText();
        }
        case " (2, 3)" -> {
            numero2 = lab2_3.getText();
        }
        case " (2, 4)" -> {
            numero2 = lab2_4.getText();
        }
        case " (2, 5)" -> {
            numero2 = lab2_5.getText();
        }
        case " (2, 6)" -> {
            numero2 = lab2_6.getText();
        }
        case " (3, 1)" -> {
            numero2 = lab3_1.getText();
        }
        case " (3, 2)" -> {
            numero2 = lab3_2.getText();
        }
        case " (3, 3)" -> {
            numero2 = lab3_3.getText();
        }
        case " (3, 4)" -> {
            numero2 = lab3_4.getText();
        }
        case " (3, 5)" -> {
            numero2 = lab3_5.getText();
        }
        case " (3, 6)" -> {
            numero2 = lab3_6.getText();
        }
        case " (4, 1)" -> {
            numero2 = lab4_1.getText();
        }
        case " (4, 2)" -> {
            numero2 = lab4_2.getText();
        }
        case " (4, 3)" -> {
            numero2 = lab4_3.getText();
        }
        case " (4, 4)" -> {
            numero2 = lab4_4.getText();
        }
        case " (4, 5)" -> {
            numero2 = lab4_5.getText();
        }
        case " (4, 6)" -> {
            numero2 = lab4_6.getText();
        }
        case " (5, 1)" -> {
            numero2 = lab5_1.getText();
        }
        case " (5, 2)" -> {
            numero2 = lab5_2.getText();
        }
        case " (5, 3)" -> {
            numero2 = lab5_3.getText();
        }
        case " (5, 4)" -> {
            numero2 = lab5_4.getText();
        }
        case " (5, 5)" -> {
            numero2 = lab5_5.getText();
        }
        case " (5, 6)" -> {
            numero2 = lab5_6.getText();
        }
        case " (6, 1)" -> {
            numero2 = lab6_1.getText();
        }
        case " (6, 2)" -> {
            numero2 = lab6_2.getText();
        }
        case " (6, 3)" -> {
            numero2 = lab6_3.getText();
        }
        case " (6, 4)" -> {
            numero2 = lab6_4.getText();
        }
        case " (6, 5)" -> {
            numero2 = lab6_5.getText();
        }
        case " (6, 6)" -> {
            numero2 = lab6_6.getText();
        }
        }
        }
        if("=".equals(op)){
            if(Integer.parseInt(numero1) != resultado){
                return false;
            }
        }
        if("-".equals(op)){
            if(Integer.parseInt(numero1)-Integer.parseInt(numero2) != resultado){
                return false;
            }
        }
        if("/".equals(op)){
            if(Integer.parseInt(numero1)/Integer.parseInt(numero2) != resultado){
                return false;
            }
        }
        int oper = 0;
        if("+".equals(op) || "x".equals(op)){
            if("x".equals(op)){
                oper = 1;
            }
            for(String ind: posicion){
                switch(posicion.get(0)){
                    case " (1, 1)" -> {
                    numero1 = lab1_1.getText();
                }
                case " (1, 2)" -> {
                    numero1 = lab1_2.getText();
                }
                case " (1, 3)" -> {
                    numero1 = lab1_3.getText();
                }
                case " (1, 4)" -> {
                    numero1 = lab1_4.getText();
                }
                case " (1, 5)" -> {
                    numero1 = lab1_5.getText();
                }
                case " (1, 6)" -> {
                    numero1 = lab1_6.getText();
                }
                case " (2, 1)" -> {
                    numero1 = lab2_1.getText();
                }
                case " (2, 2)" -> {
                    numero1 = lab2_2.getText();
                }
                case " (2, 3)" -> {
                    numero1 = lab2_3.getText();
                }
                case " (2, 4)" -> {
                    numero1 = lab2_4.getText();
                }
                case " (2, 5)" -> {
                    numero1 = lab2_5.getText();
                }
                case " (2, 6)" -> {
                    numero1 = lab2_6.getText();
                }
                case " (3, 1)" -> {
                    numero1 = lab3_1.getText();
                }
                case " (3, 2)" -> {
                    numero1 = lab3_2.getText();
                }
                case " (3, 3)" -> {
                    numero1 = lab3_3.getText();
                }
                case " (3, 4)" -> {
                    numero1 = lab3_4.getText();
                }
                case " (3, 5)" -> {
                    numero1 = lab3_5.getText();
                }
                case " (3, 6)" -> {
                    numero1 = lab3_6.getText();
                }
                case " (4, 1)" -> {
                    numero1 = lab4_1.getText();
                }
                case " (4, 2)" -> {
                    numero1 = lab4_2.getText();
                }
                case " (4, 3)" -> {
                    numero1 = lab4_3.getText();
                }
                case " (4, 4)" -> {
                    numero1 = lab4_4.getText();
                }
                case " (4, 5)" -> {
                    numero1 = lab4_5.getText();
                }
                case " (4, 6)" -> {
                    numero1 = lab4_6.getText();
                }
                case " (5, 1)" -> {
                    numero1 = lab5_1.getText();
                }
                case " (5, 2)" -> {
                    numero1 = lab5_2.getText();
                }
                case " (5, 3)" -> {
                    numero1 = lab5_3.getText();
                }
                case " (5, 4)" -> {
                    numero1 = lab5_4.getText();
                }
                case " (5, 5)" -> {
                    numero1 = lab5_5.getText();
                }
                case " (5, 6)" -> {
                    numero1 = lab5_6.getText();
                }
                case " (6, 1)" -> {
                    numero1 = lab6_1.getText();
                }
                case " (6, 2)" -> {
                    numero1 = lab6_2.getText();
                }
                case " (6, 3)" -> {
                    numero1 = lab6_3.getText();
                }
                case " (6, 4)" -> {
                    numero1 = lab6_4.getText();
                }
                case " (6, 5)" -> {
                    numero1 = lab6_5.getText();
                }
                case " (6, 6)" -> {
                    numero1 = lab6_6.getText();
                }
                }
                if("+".equals(op)){
                    oper= oper + Integer.parseInt(numero1);
                }
                if("x".equals(op)){
                    oper= oper * Integer.parseInt(numero1);
                }
            }
        }
        if(oper != resultado){
            return false;
        }
        return true;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txt5_1 = new javax.swing.JTextField();
        txt2_5 = new javax.swing.JTextField();
        txt6_4 = new javax.swing.JTextField();
        txt2_6 = new javax.swing.JTextField();
        lab4_5 = new javax.swing.JTextField();
        txt5_2 = new javax.swing.JTextField();
        lab4_6 = new javax.swing.JTextField();
        txt3_3 = new javax.swing.JTextField();
        lab5_5 = new javax.swing.JTextField();
        txt5_3 = new javax.swing.JTextField();
        lab5_6 = new javax.swing.JTextField();
        txt3_1 = new javax.swing.JTextField();
        lab5_1 = new javax.swing.JTextField();
        txt3_5 = new javax.swing.JTextField();
        lab5_2 = new javax.swing.JTextField();
        txt5_4 = new javax.swing.JTextField();
        lab5_3 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        lab5_4 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        lab6_5 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        lab6_6 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        txt3_6 = new javax.swing.JTextField();
        txt3_2 = new javax.swing.JTextField();
        txt3_4 = new javax.swing.JTextField();
        txt5_5 = new javax.swing.JTextField();
        lab6_1 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        txt4_1 = new javax.swing.JTextField();
        lab6_2 = new javax.swing.JTextField();
        jButton6 = new javax.swing.JButton();
        txt5_6 = new javax.swing.JTextField();
        lab6_3 = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        lab6_4 = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        lab1_1 = new javax.swing.JTextField();
        lab1_2 = new javax.swing.JTextField();
        txt4_2 = new javax.swing.JTextField();
        txt1_1 = new javax.swing.JTextField();
        txt6_3 = new javax.swing.JTextField();
        txt1_2 = new javax.swing.JTextField();
        lab1_3 = new javax.swing.JTextField();
        txt4_3 = new javax.swing.JTextField();
        lab1_4 = new javax.swing.JTextField();
        txt1_3 = new javax.swing.JTextField();
        lab1_5 = new javax.swing.JTextField();
        txt6_1 = new javax.swing.JTextField();
        lab1_6 = new javax.swing.JTextField();
        txt1_4 = new javax.swing.JTextField();
        lab2_1 = new javax.swing.JTextField();
        txt1_5 = new javax.swing.JTextField();
        lab2_2 = new javax.swing.JTextField();
        txt4_4 = new javax.swing.JTextField();
        lab2_3 = new javax.swing.JTextField();
        lab2_4 = new javax.swing.JTextField();
        lab2_5 = new javax.swing.JTextField();
        lab2_6 = new javax.swing.JTextField();
        txt6_5 = new javax.swing.JTextField();
        txt1_6 = new javax.swing.JTextField();
        txt4_5 = new javax.swing.JTextField();
        txt2_1 = new javax.swing.JTextField();
        lab3_1 = new javax.swing.JTextField();
        txt6_6 = new javax.swing.JTextField();
        lab3_2 = new javax.swing.JTextField();
        txt2_2 = new javax.swing.JTextField();
        lab3_3 = new javax.swing.JTextField();
        txt4_6 = new javax.swing.JTextField();
        lab3_4 = new javax.swing.JTextField();
        txt2_3 = new javax.swing.JTextField();
        lab3_5 = new javax.swing.JTextField();
        txt6_2 = new javax.swing.JTextField();
        lab3_6 = new javax.swing.JTextField();
        txt2_4 = new javax.swing.JTextField();
        lab4_1 = new javax.swing.JTextField();
        lab4_2 = new javax.swing.JTextField();
        lab4_3 = new javax.swing.JTextField();
        lab4_4 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txt5_1.setEditable(false);
        txt5_1.setBackground(new java.awt.Color(255, 255, 255));
        txt5_1.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt5_1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt5_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt5_1MouseClicked(evt);
            }
        });

        txt2_5.setEditable(false);
        txt2_5.setBackground(new java.awt.Color(255, 255, 255));
        txt2_5.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt2_5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt2_5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt2_5MouseClicked(evt);
            }
        });

        txt6_4.setEditable(false);
        txt6_4.setBackground(new java.awt.Color(255, 255, 255));
        txt6_4.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt6_4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt6_4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt6_4MouseClicked(evt);
            }
        });

        txt2_6.setEditable(false);
        txt2_6.setBackground(new java.awt.Color(255, 255, 255));
        txt2_6.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt2_6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt2_6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt2_6MouseClicked(evt);
            }
        });

        lab4_5.setEditable(false);

        txt5_2.setEditable(false);
        txt5_2.setBackground(new java.awt.Color(255, 255, 255));
        txt5_2.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt5_2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt5_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt5_2MouseClicked(evt);
            }
        });

        lab4_6.setEditable(false);

        txt3_3.setEditable(false);
        txt3_3.setBackground(new java.awt.Color(255, 255, 255));
        txt3_3.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt3_3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt3_3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt3_3MouseClicked(evt);
            }
        });

        lab5_5.setEditable(false);

        txt5_3.setEditable(false);
        txt5_3.setBackground(new java.awt.Color(255, 255, 255));
        txt5_3.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt5_3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt5_3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt5_3MouseClicked(evt);
            }
        });

        lab5_6.setEditable(false);

        txt3_1.setEditable(false);
        txt3_1.setBackground(new java.awt.Color(255, 255, 255));
        txt3_1.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt3_1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt3_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt3_1MouseClicked(evt);
            }
        });
        txt3_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt3_1ActionPerformed(evt);
            }
        });

        lab5_1.setEditable(false);

        txt3_5.setEditable(false);
        txt3_5.setBackground(new java.awt.Color(255, 255, 255));
        txt3_5.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt3_5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt3_5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt3_5MouseClicked(evt);
            }
        });

        lab5_2.setEditable(false);

        txt5_4.setEditable(false);
        txt5_4.setBackground(new java.awt.Color(255, 255, 255));
        txt5_4.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt5_4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt5_4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt5_4MouseClicked(evt);
            }
        });

        lab5_3.setEditable(false);

        jButton1.setBackground(new java.awt.Color(0, 0, 153));
        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Iniciar Juego");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        lab5_4.setEditable(false);

        jButton2.setBackground(new java.awt.Color(0, 0, 153));
        jButton2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Deshacer Jugada");
        jButton2.setEnabled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        lab6_5.setEditable(false);

        jButton3.setBackground(new java.awt.Color(0, 0, 153));
        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Terminar Juego");
        jButton3.setEnabled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        lab6_6.setEditable(false);

        jButton4.setBackground(new java.awt.Color(0, 0, 153));
        jButton4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("Otro Juego");
        jButton4.setEnabled(false);

        txt3_6.setEditable(false);
        txt3_6.setBackground(new java.awt.Color(255, 255, 255));
        txt3_6.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt3_6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt3_6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt3_6MouseClicked(evt);
            }
        });

        txt3_2.setEditable(false);
        txt3_2.setBackground(new java.awt.Color(255, 255, 255));
        txt3_2.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt3_2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt3_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt3_2MouseClicked(evt);
            }
        });

        txt3_4.setEditable(false);
        txt3_4.setBackground(new java.awt.Color(255, 255, 255));
        txt3_4.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt3_4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt3_4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt3_4MouseClicked(evt);
            }
        });

        txt5_5.setEditable(false);
        txt5_5.setBackground(new java.awt.Color(255, 255, 255));
        txt5_5.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt5_5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt5_5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt5_5MouseClicked(evt);
            }
        });

        lab6_1.setEditable(false);

        jButton5.setBackground(new java.awt.Color(0, 0, 153));
        jButton5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("Validar Juego");
        jButton5.setEnabled(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        txt4_1.setEditable(false);
        txt4_1.setBackground(new java.awt.Color(255, 255, 255));
        txt4_1.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt4_1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt4_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt4_1MouseClicked(evt);
            }
        });

        lab6_2.setEditable(false);

        jButton6.setBackground(new java.awt.Color(0, 0, 153));
        jButton6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("Rehacer Jugada");
        jButton6.setEnabled(false);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        txt5_6.setEditable(false);
        txt5_6.setBackground(new java.awt.Color(255, 255, 255));
        txt5_6.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt5_6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt5_6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt5_6MouseClicked(evt);
            }
        });

        lab6_3.setEditable(false);

        jButton7.setBackground(new java.awt.Color(0, 0, 153));
        jButton7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Reiniciar Juego");
        jButton7.setEnabled(false);

        lab6_4.setEditable(false);

        jButton8.setBackground(new java.awt.Color(0, 0, 153));
        jButton8.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("1");
        jButton8.setEnabled(false);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setBackground(new java.awt.Color(0, 0, 153));
        jButton9.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("2");
        jButton9.setEnabled(false);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setBackground(new java.awt.Color(0, 0, 153));
        jButton10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("3");
        jButton10.setEnabled(false);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setBackground(new java.awt.Color(0, 0, 153));
        jButton11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("4");
        jButton11.setEnabled(false);
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setBackground(new java.awt.Color(0, 0, 153));
        jButton12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setText("6");
        jButton12.setEnabled(false);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.setBackground(new java.awt.Color(0, 0, 153));
        jButton13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton13.setForeground(new java.awt.Color(255, 255, 255));
        jButton13.setText("5");
        jButton13.setEnabled(false);
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setBackground(new java.awt.Color(0, 0, 153));
        jButton14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton14.setForeground(new java.awt.Color(255, 255, 255));
        jButton14.setText("Borrar");
        jButton14.setEnabled(false);
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        lab1_1.setEditable(false);

        lab1_2.setEditable(false);

        txt4_2.setEditable(false);
        txt4_2.setBackground(new java.awt.Color(255, 255, 255));
        txt4_2.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt4_2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt4_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt4_2MouseClicked(evt);
            }
        });

        txt1_1.setEditable(false);
        txt1_1.setBackground(new java.awt.Color(255, 255, 255));
        txt1_1.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt1_1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt1_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt1_1MouseClicked(evt);
            }
        });

        txt6_3.setEditable(false);
        txt6_3.setBackground(new java.awt.Color(255, 255, 255));
        txt6_3.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt6_3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt6_3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt6_3MouseClicked(evt);
            }
        });

        txt1_2.setEditable(false);
        txt1_2.setBackground(new java.awt.Color(255, 255, 255));
        txt1_2.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt1_2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt1_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt1_2MouseClicked(evt);
            }
        });
        txt1_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt1_2ActionPerformed(evt);
            }
        });

        lab1_3.setEditable(false);

        txt4_3.setEditable(false);
        txt4_3.setBackground(new java.awt.Color(255, 255, 255));
        txt4_3.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt4_3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt4_3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt4_3MouseClicked(evt);
            }
        });

        lab1_4.setEditable(false);

        txt1_3.setEditable(false);
        txt1_3.setBackground(new java.awt.Color(255, 255, 255));
        txt1_3.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt1_3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt1_3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt1_3MouseClicked(evt);
            }
        });

        lab1_5.setEditable(false);

        txt6_1.setEditable(false);
        txt6_1.setBackground(new java.awt.Color(255, 255, 255));
        txt6_1.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt6_1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt6_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt6_1MouseClicked(evt);
            }
        });

        lab1_6.setEditable(false);

        txt1_4.setEditable(false);
        txt1_4.setBackground(new java.awt.Color(255, 255, 255));
        txt1_4.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt1_4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt1_4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt1_4MouseClicked(evt);
            }
        });

        lab2_1.setEditable(false);

        txt1_5.setEditable(false);
        txt1_5.setBackground(new java.awt.Color(255, 255, 255));
        txt1_5.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt1_5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt1_5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt1_5MouseClicked(evt);
            }
        });

        lab2_2.setEditable(false);

        txt4_4.setEditable(false);
        txt4_4.setBackground(new java.awt.Color(255, 255, 255));
        txt4_4.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt4_4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt4_4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt4_4MouseClicked(evt);
            }
        });
        txt4_4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt4_4ActionPerformed(evt);
            }
        });

        lab2_3.setEditable(false);

        lab2_4.setEditable(false);

        lab2_5.setEditable(false);

        lab2_6.setEditable(false);

        txt6_5.setEditable(false);
        txt6_5.setBackground(new java.awt.Color(255, 255, 255));
        txt6_5.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt6_5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt6_5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt6_5MouseClicked(evt);
            }
        });

        txt1_6.setEditable(false);
        txt1_6.setBackground(new java.awt.Color(255, 255, 255));
        txt1_6.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt1_6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt1_6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt1_6MouseClicked(evt);
            }
        });

        txt4_5.setEditable(false);
        txt4_5.setBackground(new java.awt.Color(255, 255, 255));
        txt4_5.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt4_5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt4_5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt4_5MouseClicked(evt);
            }
        });

        txt2_1.setEditable(false);
        txt2_1.setBackground(new java.awt.Color(255, 255, 255));
        txt2_1.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt2_1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt2_1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt2_1MouseClicked(evt);
            }
        });

        lab3_1.setEditable(false);

        txt6_6.setEditable(false);
        txt6_6.setBackground(new java.awt.Color(255, 255, 255));
        txt6_6.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt6_6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt6_6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt6_6MouseClicked(evt);
            }
        });
        txt6_6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt6_6ActionPerformed(evt);
            }
        });

        lab3_2.setEditable(false);

        txt2_2.setEditable(false);
        txt2_2.setBackground(new java.awt.Color(255, 255, 255));
        txt2_2.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt2_2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt2_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt2_2MouseClicked(evt);
            }
        });

        lab3_3.setEditable(false);

        txt4_6.setEditable(false);
        txt4_6.setBackground(new java.awt.Color(255, 255, 255));
        txt4_6.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt4_6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt4_6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt4_6MouseClicked(evt);
            }
        });

        lab3_4.setEditable(false);

        txt2_3.setEditable(false);
        txt2_3.setBackground(new java.awt.Color(255, 255, 255));
        txt2_3.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt2_3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt2_3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt2_3MouseClicked(evt);
            }
        });

        lab3_5.setEditable(false);

        txt6_2.setEditable(false);
        txt6_2.setBackground(new java.awt.Color(255, 255, 255));
        txt6_2.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt6_2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt6_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt6_2MouseClicked(evt);
            }
        });

        lab3_6.setEditable(false);

        txt2_4.setEditable(false);
        txt2_4.setBackground(new java.awt.Color(255, 255, 255));
        txt2_4.setFont(new java.awt.Font("Segoe UI", 0, 48)); // NOI18N
        txt2_4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt2_4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txt2_4MouseClicked(evt);
            }
        });

        lab4_1.setEditable(false);

        lab4_2.setEditable(false);

        lab4_3.setEditable(false);

        lab4_4.setEditable(false);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(100, 100, 100))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txt2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txt2_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txt2_3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txt2_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txt2_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txt2_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(txt3_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, 0)
                                                .addComponent(txt3_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(166, 166, 166)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(txt3_3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(0, 0, 0)
                                                        .addComponent(txt3_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(0, 0, 0)
                                                        .addComponent(txt3_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(txt4_3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(0, 0, 0)
                                                        .addComponent(txt4_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(0, 0, 0)
                                                        .addComponent(txt4_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                        .addGap(0, 0, 0)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txt3_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txt4_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(txt5_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(0, 0, 0)
                                            .addComponent(txt5_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(0, 0, 0)
                                            .addComponent(txt5_3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(0, 0, 0)
                                            .addComponent(txt5_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(0, 0, 0)
                                            .addComponent(txt5_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(0, 0, 0)
                                            .addComponent(txt5_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(txt4_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(0, 0, 0)
                                            .addComponent(txt4_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(332, 332, 332)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txt6_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txt6_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txt6_3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txt6_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txt6_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txt6_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(166, 166, 166)
                                                .addComponent(lab2_3))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addComponent(lab1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, 0)
                                                .addComponent(lab1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, 0)
                                                .addComponent(lab1_3))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(lab2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txt1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txt1_2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(lab2_2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addComponent(txt1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                    .addComponent(txt1_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(0, 0, 0)
                                                    .addComponent(txt1_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(0, 0, 0)
                                                    .addComponent(txt1_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                    .addComponent(lab1_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(0, 0, 0)
                                                    .addComponent(lab1_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(0, 0, 0)
                                                    .addComponent(lab1_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(lab2_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, 0)
                                                .addComponent(lab2_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, 0)
                                                .addComponent(lab2_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(166, 166, 166)
                                            .addComponent(lab3_3))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(lab3_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(0, 0, 0)
                                            .addComponent(lab3_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(83, 83, 83)))
                                    .addGap(0, 0, 0)
                                    .addComponent(lab3_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, 0)
                                    .addComponent(lab3_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, 0)
                                    .addComponent(lab3_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(166, 166, 166)
                                            .addComponent(lab4_3))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(lab4_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(0, 0, 0)
                                            .addComponent(lab4_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(83, 83, 83)))
                                    .addGap(0, 0, 0)
                                    .addComponent(lab4_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, 0)
                                    .addComponent(lab4_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, 0)
                                    .addComponent(lab4_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(166, 166, 166)
                                            .addComponent(lab5_3))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(lab5_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(0, 0, 0)
                                            .addComponent(lab5_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(83, 83, 83)))
                                    .addGap(0, 0, 0)
                                    .addComponent(lab5_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, 0)
                                    .addComponent(lab5_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(0, 0, 0)
                                    .addComponent(lab5_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(166, 166, 166)
                                        .addComponent(lab6_3))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(lab6_1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(lab6_2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(83, 83, 83)))
                                .addGap(0, 0, 0)
                                .addComponent(lab6_4, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(lab6_5, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(lab6_6, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 129, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lab1_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab1_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab1_4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab1_5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab1_6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab1_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt1_4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt1_5, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt1_6, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lab2_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab2_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab2_4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab2_5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab2_6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab2_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt2_3, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt2_2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt2_4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt2_5, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt2_6, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lab3_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab3_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab3_4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab3_5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab3_6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab3_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt3_1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt3_2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt3_3, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt3_4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt3_5, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt3_6, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lab4_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab4_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab4_4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab4_5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab4_6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab4_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt4_2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt4_3, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt4_4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt4_5, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txt4_6, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txt4_1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lab5_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab5_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab5_4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab5_5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab5_6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab5_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt5_1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt5_2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt5_3, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt5_4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt5_5, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt5_6, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lab6_1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab6_2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab6_4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab6_5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab6_6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lab6_3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt6_1, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt6_2, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt6_3, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt6_4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt6_5, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt6_6, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(jButton3)
                    .addComponent(jButton2)
                    .addComponent(jButton1))
                .addGap(42, 42, 42))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txt5_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt5_1MouseClicked
        // TODO add your handling code here:
        txt5_1.setBackground(Color.blue);
        valorCelda = txt5_1.getText();
        posicion = "(5, 1)";
    }//GEN-LAST:event_txt5_1MouseClicked

    private void txt2_5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt2_5MouseClicked
        // TODO add your handling code here:
        txt2_5.setBackground(Color.blue);
        valorCelda = txt2_5.getText();
        posicion = "(2, 5)";
    }//GEN-LAST:event_txt2_5MouseClicked

    private void txt6_4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt6_4MouseClicked
        // TODO add your handling code here:
        txt6_4.setBackground(Color.blue);
        valorCelda = txt6_4.getText();
        posicion = "(6, 4)";
    }//GEN-LAST:event_txt6_4MouseClicked

    private void txt2_6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt2_6MouseClicked
        // TODO add your handling code here:
        txt2_6.setBackground(Color.blue);
        valorCelda = txt2_6.getText();
        posicion = "(2, 6)";
    }//GEN-LAST:event_txt2_6MouseClicked

    private void txt5_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt5_2MouseClicked
        // TODO add your handling code here:
        txt5_2.setBackground(Color.blue);
        valorCelda = txt5_2.getText();
        posicion = "(5, 2)";
    }//GEN-LAST:event_txt5_2MouseClicked

    private void txt3_3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt3_3MouseClicked
        // TODO add your handling code here:
        txt3_3.setBackground(Color.blue);
        valorCelda = txt3_3.getText();
        posicion = "(3, 3)";
    }//GEN-LAST:event_txt3_3MouseClicked

    private void txt5_3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt5_3MouseClicked
        // TODO add your handling code here:
        txt5_3.setBackground(Color.blue);
        valorCelda = txt5_3.getText();
        posicion = "(5, 3)";
    }//GEN-LAST:event_txt5_3MouseClicked

    private void txt3_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt3_1MouseClicked
        // TODO add your handling code here:
        txt3_1.setBackground(Color.blue);
        valorCelda = txt3_1.getText();
        posicion = "(3, 1)";
    }//GEN-LAST:event_txt3_1MouseClicked

    private void txt3_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt3_1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt3_1ActionPerformed

    private void txt3_5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt3_5MouseClicked
        // TODO add your handling code here:
        txt3_5.setBackground(Color.blue);
        valorCelda = txt3_5.getText();
        posicion = "(3, 5)";
    }//GEN-LAST:event_txt3_5MouseClicked

    private void txt5_4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt5_4MouseClicked
        // TODO add your handling code here:
        txt5_4.setBackground(Color.blue);
        valorCelda = txt5_4.getText();
        posicion = "(5, 4)";
    }//GEN-LAST:event_txt5_4MouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        jButton1.setEnabled(false);
        jButton2.setEnabled(true);
        jButton3.setEnabled(true);
        jButton4.setEnabled(true);
        jButton5.setEnabled(true);
        jButton6.setEnabled(true);
        jButton7.setEnabled(true);
        jButton8.setEnabled(true);
        jButton9.setEnabled(true);
        jButton10.setEnabled(true);
        jButton11.setEnabled(true);
        jButton12.setEnabled(true);
        jButton13.setEnabled(true);
        jButton14.setEnabled(true);
        pintarOperaciones(getPartidaElegida());
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        Movimiento movimientoDeshecho = movimientosHechos.deshacerJugada();
        movimientosBorrados.agregarMovimiento(movimientoDeshecho);
        posicion = movimientoDeshecho.getPosicionCelda();
        switch(posicion){
            case "(1, 1)" -> {
                txt1_1.setText("");
                txt1_1.setBackground(Color.white);
            }
            case "(1, 2)" -> {
                txt1_2.setText("");
                txt1_2.setBackground(Color.white);
            }
            case "(1, 3)" -> {
                txt1_3.setText("");
                txt1_3.setBackground(Color.white);
            }
            case "(1, 4)" -> {
                txt1_4.setText("");
                txt1_4.setBackground(Color.white);
            }
            case "(1, 5)" -> {
                txt1_5.setText("");
                txt1_5.setBackground(Color.white);
            }
            case "(1, 6)" -> {
                txt1_6.setText("");
                txt1_6.setBackground(Color.white);
            }
            case "(2, 1)" -> {
                txt2_1.setText("");
                txt2_1.setBackground(Color.white);
            }
            case "(2, 2)" -> {
                txt2_2.setText("");
                txt2_2.setBackground(Color.white);
            }
            case "(2, 3)" -> {
                txt2_3.setText("");
                txt2_3.setBackground(Color.white);
            }
            case "(2, 4)" -> {
                txt2_4.setText("");
                txt2_4.setBackground(Color.white);
            }
            case "(2, 5)" -> {
                txt2_5.setText("");
                txt2_5.setBackground(Color.white);
            }
            case "(2, 6)" -> {
                txt2_6.setText("");
                txt2_6.setBackground(Color.white);
            }
            case "(3, 1)" -> {
                txt3_1.setText("");
                txt3_1.setBackground(Color.white);
            }
            case "(3, 2)" -> {
                txt3_2.setText("");
                txt3_2.setBackground(Color.white);
            }
            case "(3, 3)" -> {
                txt3_3.setText("");
                txt3_3.setBackground(Color.white);
            }
            case "(3, 4)" -> {
                txt3_4.setText("");
                txt3_4.setBackground(Color.white);
            }
            case "(3, 5)" -> {
                txt3_5.setText("");
                txt3_5.setBackground(Color.white);
            }
            case "(3, 6)" -> {
                txt3_6.setText("");
                txt3_6.setBackground(Color.white);
            }
            case "(4, 1)" -> {
                txt4_1.setText("");
                txt4_1.setBackground(Color.white);
            }
            case "(4, 2)" -> {
                txt4_2.setText("");
                txt4_2.setBackground(Color.white);
            }
            case "(4, 3)" -> {
                txt4_3.setText("");
                txt4_3.setBackground(Color.white);
            }
            case "(4, 4)" -> {
                txt4_4.setText("");
                txt4_4.setBackground(Color.white);
            }
            case "(4, 5)" -> {
                txt4_5.setText("");
                txt4_5.setBackground(Color.white);
            }
            case "(4, 6)" -> {
                txt4_6.setText("");
                txt4_6.setBackground(Color.white);
            }
            case "(5, 1)" -> {
                txt5_1.setText("");
                txt5_1.setBackground(Color.white);
            }
            case "(5, 2)" -> {
                txt5_2.setText("");
                txt5_2.setBackground(Color.white);
            }
            case "(5, 3)" -> {
                txt5_3.setText("");
                txt5_3.setBackground(Color.white);
            }
            case "(5, 4)" -> {
                txt5_4.setText("");
                txt5_4.setBackground(Color.white);
            }
            case "(5, 5)" -> {
                txt5_5.setText("");
                txt5_5.setBackground(Color.white);
            }
            case "(5, 6)" -> {
                txt5_6.setText("");
                txt5_6.setBackground(Color.white);
            }
            case "(6, 1)" -> {
                txt6_1.setText("");
                txt6_1.setBackground(Color.white);
            }
            case "(6, 2)" -> {
                txt6_2.setText("");
                txt6_2.setBackground(Color.white);
            }
            case "(6, 3)" -> {
                txt6_3.setText("");
                txt6_3.setBackground(Color.white);
            }
            case "(6, 4)" -> {
                txt6_4.setText("");
                txt6_4.setBackground(Color.white);
            }
            case "(6, 5)" -> {
                txt6_5.setText("");
                txt6_5.setBackground(Color.white);
            }
            case "(6, 6)" -> {
                txt6_6.setText("");
                txt6_6.setBackground(Color.white);
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txt3_6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt3_6MouseClicked
        // TODO add your handling code here:
        txt3_6.setBackground(Color.blue);
        valorCelda = txt3_6.getText();
        posicion = "(3, 6)";
    }//GEN-LAST:event_txt3_6MouseClicked

    private void txt3_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt3_2MouseClicked
        // TODO add your handling code here:
        txt3_2.setBackground(Color.blue);
        valorCelda = txt3_2.getText();
        posicion = "(3, 2)";
    }//GEN-LAST:event_txt3_2MouseClicked

    private void txt3_4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt3_4MouseClicked
        // TODO add your handling code here:
        txt3_4.setBackground(Color.blue);
        valorCelda = txt3_4.getText();
        posicion = "(3, 4)";
    }//GEN-LAST:event_txt3_4MouseClicked

    private void txt5_5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt5_5MouseClicked
        // TODO add your handling code here:
        txt5_5.setBackground(Color.blue);
        valorCelda = txt5_5.getText();
        posicion = "(5, 5)";
    }//GEN-LAST:event_txt5_5MouseClicked

    private void txt4_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt4_1MouseClicked
        // TODO add your handling code here:
        txt4_1.setBackground(Color.blue);
        valorCelda = txt4_1.getText();
        posicion = "(4, 1)";
    }//GEN-LAST:event_txt4_1MouseClicked

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        Movimiento movimientoRehecho = movimientosBorrados.rehacerJugada();
        movimientosHechos.agregarMovimiento(movimientoRehecho);
        String jugada = String.valueOf(movimientoRehecho.getValorCelda());
        posicion = movimientoRehecho.getPosicionCelda();
        switch(posicion){
            case "(1, 1)" -> {
                txt1_1.setText(jugada);
                txt1_1.setBackground(Color.white);
            }
            case "(1, 2)" -> {
                txt1_2.setText(jugada);
                txt1_2.setBackground(Color.white);
            }
            case "(1, 3)" -> {
                txt1_3.setText(jugada);
                txt1_3.setBackground(Color.white);
            }
            case "(1, 4)" -> {
                txt1_4.setText(jugada);
                txt1_4.setBackground(Color.white);
            }
            case "(1, 5)" -> {
                txt1_5.setText(jugada);
                txt1_5.setBackground(Color.white);
            }
            case "(1, 6)" -> {
                txt1_6.setText(jugada);
                txt1_6.setBackground(Color.white);
            }
            case "(2, 1)" -> {
                txt2_1.setText(jugada);
                txt2_1.setBackground(Color.white);
            }
            case "(2, 2)" -> {
                txt2_2.setText(jugada);
                txt2_2.setBackground(Color.white);
            }
            case "(2, 3)" -> {
                txt2_3.setText(jugada);
                txt2_3.setBackground(Color.white);
            }
            case "(2, 4)" -> {
                txt2_4.setText(jugada);
                txt2_4.setBackground(Color.white);
            }
            case "(2, 5)" -> {
                txt2_5.setText(jugada);
                txt2_5.setBackground(Color.white);
            }
            case "(2, 6)" -> {
                txt2_6.setText(jugada);
                txt2_6.setBackground(Color.white);
            }
            case "(3, 1)" -> {
                txt3_1.setText(jugada);
                txt3_1.setBackground(Color.white);
            }
            case "(3, 2)" -> {
                txt3_2.setText(jugada);
                txt3_2.setBackground(Color.white);
            }
            case "(3, 3)" -> {
                txt3_3.setText(jugada);
                txt3_3.setBackground(Color.white);
            }
            case "(3, 4)" -> {
                txt3_4.setText(jugada);
                txt3_4.setBackground(Color.white);
            }
            case "(3, 5)" -> {
                txt3_5.setText(jugada);
                txt3_5.setBackground(Color.white);
            }
            case "(3, 6)" -> {
                txt3_6.setText(jugada);
                txt3_6.setBackground(Color.white);
            }
            case "(4, 1)" -> {
                txt4_1.setText(jugada);
                txt4_1.setBackground(Color.white);
            }
            case "(4, 2)" -> {
                txt4_2.setText(jugada);
                txt4_2.setBackground(Color.white);
            }
            case "(4, 3)" -> {
                txt4_3.setText(jugada);
                txt4_3.setBackground(Color.white);
            }
            case "(4, 4)" -> {
                txt4_4.setText(jugada);
                txt4_4.setBackground(Color.white);
            }
            case "(4, 5)" -> {
                txt4_5.setText(jugada);
                txt4_5.setBackground(Color.white);
            }
            case "(4, 6)" -> {
                txt4_6.setText(jugada);
                txt4_6.setBackground(Color.white);
            }
            case "(5, 1)" -> {
                txt5_1.setText(jugada);
                txt5_1.setBackground(Color.white);
            }
            case "(5, 2)" -> {
                txt5_2.setText(jugada);
                txt5_2.setBackground(Color.white);
            }
            case "(5, 3)" -> {
                txt5_3.setText(jugada);
                txt5_3.setBackground(Color.white);
            }
            case "(5, 4)" -> {
                txt5_4.setText(jugada);
                txt5_4.setBackground(Color.white);
            }
            case "(5, 5)" -> {
                txt5_5.setText(jugada);
                txt5_5.setBackground(Color.white);
            }
            case "(5, 6)" -> {
                txt5_6.setText(jugada);
                txt5_6.setBackground(Color.white);
            }
            case "(6, 1)" -> {
                txt6_1.setText(jugada);
                txt6_1.setBackground(Color.white);
            }
            case "(6, 2)" -> {
                txt6_2.setText(jugada);
                txt6_2.setBackground(Color.white);
            }
            case "(6, 3)" -> {
                txt6_3.setText(jugada);
                txt6_3.setBackground(Color.white);
            }
            case "(6, 4)" -> {
                txt6_4.setText(jugada);
                txt6_4.setBackground(Color.white);
            }
            case "(6, 5)" -> {
                txt6_5.setText(jugada);
                txt6_5.setBackground(Color.white);
            }
            case "(6, 6)" -> {
                txt6_6.setText(jugada);
                txt6_6.setBackground(Color.white);
            }
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void txt5_6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt5_6MouseClicked
        // TODO add your handling code here:
        txt5_6.setBackground(Color.blue);
        valorCelda = txt5_6.getText();
        posicion = "(5, 6)";
    }//GEN-LAST:event_txt5_6MouseClicked

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        switch(posicion){
            case "(1, 1)" -> {
                txt1_1.setText("1");
                txt1_1.setBackground(Color.white);
            }
            case "(1, 2)" -> {
                txt1_2.setText("1");
                txt1_2.setBackground(Color.white);
            }
            case "(1, 3)" -> {
                txt1_3.setText("1");
                txt1_3.setBackground(Color.white);
            }
            case "(1, 4)" -> {
                txt1_4.setText("1");
                txt1_4.setBackground(Color.white);
            }
            case "(1, 5)" -> {
                txt1_5.setText("1");
                txt1_5.setBackground(Color.white);
            }
            case "(1, 6)" -> {
                txt1_6.setText("1");
                txt1_6.setBackground(Color.white);
            }
            case "(2, 1)" -> {
                txt2_1.setText("1");
                txt2_1.setBackground(Color.white);
            }
            case "(2, 2)" -> {
                txt2_2.setText("1");
                txt2_2.setBackground(Color.white);
            }
            case "(2, 3)" -> {
                txt2_3.setText("1");
                txt2_3.setBackground(Color.white);
            }
            case "(2, 4)" -> {
                txt2_4.setText("1");
                txt2_4.setBackground(Color.white);
            }
            case "(2, 5)" -> {
                txt2_5.setText("1");
                txt2_5.setBackground(Color.white);
            }
            case "(2, 6)" -> {
                txt2_6.setText("1");
                txt2_6.setBackground(Color.white);
            }
            case "(3, 1)" -> {
                txt3_1.setText("1");
                txt3_1.setBackground(Color.white);
            }
            case "(3, 2)" -> {
                txt3_2.setText("1");
                txt3_2.setBackground(Color.white);
            }
            case "(3, 3)" -> {
                txt3_3.setText("1");
                txt3_3.setBackground(Color.white);
            }
            case "(3, 4)" -> {
                txt3_4.setText("1");
                txt3_4.setBackground(Color.white);
            }
            case "(3, 5)" -> {
                txt3_5.setText("1");
                txt3_5.setBackground(Color.white);
            }
            case "(3, 6)" -> {
                txt3_6.setText("1");
                txt3_6.setBackground(Color.white);
            }
            case "(4, 1)" -> {
                txt4_1.setText("1");
                txt4_1.setBackground(Color.white);
            }
            case "(4, 2)" -> {
                txt4_2.setText("1");
                txt4_2.setBackground(Color.white);
            }
            case "(4, 3)" -> {
                txt4_3.setText("1");
                txt4_3.setBackground(Color.white);
            }
            case "(4, 4)" -> {
                txt4_4.setText("1");
                txt4_4.setBackground(Color.white);
            }
            case "(4, 5)" -> {
                txt4_5.setText("1");
                txt4_5.setBackground(Color.white);
            }
            case "(4, 6)" -> {
                txt4_6.setText("1");
                txt4_6.setBackground(Color.white);
            }
            case "(5, 1)" -> {
                txt5_1.setText("1");
                txt5_1.setBackground(Color.white);
            }
            case "(5, 2)" -> {
                txt5_2.setText("1");
                txt5_2.setBackground(Color.white);
            }
            case "(5, 3)" -> {
                txt5_3.setText("1");
                txt5_3.setBackground(Color.white);
            }
            case "(5, 4)" -> {
                txt5_4.setText("1");
                txt5_4.setBackground(Color.white);
            }
            case "(5, 5)" -> {
                txt5_5.setText("1");
                txt5_5.setBackground(Color.white);
            }
            case "(5, 6)" -> {
                txt5_6.setText("1");
                txt5_6.setBackground(Color.white);
            }
            case "(6, 1)" -> {
                txt6_1.setText("1");
                txt6_1.setBackground(Color.white);
            }
            case "(6, 2)" -> {
                txt6_2.setText("1");
                txt6_2.setBackground(Color.white);
            }
            case "(6, 3)" -> {
                txt6_3.setText("1");
                txt6_3.setBackground(Color.white);
            }
            case "(6, 4)" -> {
                txt6_4.setText("1");
                txt6_4.setBackground(Color.white);
            }
            case "(6, 5)" -> {
                txt6_5.setText("1");
                txt6_5.setBackground(Color.white);
            }
            case "(6, 6)" -> {
                txt6_6.setText("1");
                txt6_6.setBackground(Color.white);
            }
        }
        Movimiento movimiento = new Movimiento(1, posicion);
        movimientosHechos.agregarMovimiento(movimiento);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        switch(posicion){
            case "(1, 1)" -> {
                txt1_1.setText("2");
                txt1_1.setBackground(Color.white);
            }
            case "(1, 2)" -> {
                txt1_2.setText("2");
                txt1_2.setBackground(Color.white);
            }
            case "(1, 3)" -> {
                txt1_3.setText("2");
                txt1_3.setBackground(Color.white);
            }
            case "(1, 4)" -> {
                txt1_4.setText("2");
                txt1_4.setBackground(Color.white);
            }
            case "(1, 5)" -> {
                txt1_5.setText("2");
                txt1_5.setBackground(Color.white);
            }
            case "(1, 6)" -> {
                txt1_6.setText("2");
                txt1_6.setBackground(Color.white);
            }
            case "(2, 1)" -> {
                txt2_1.setText("2");
                txt2_1.setBackground(Color.white);
            }
            case "(2, 2)" -> {
                txt2_2.setText("2");
                txt2_2.setBackground(Color.white);
            }
            case "(2, 3)" -> {
                txt2_3.setText("2");
                txt2_3.setBackground(Color.white);
            }
            case "(2, 4)" -> {
                txt2_4.setText("2");
                txt2_4.setBackground(Color.white);
            }
            case "(2, 5)" -> {
                txt2_5.setText("2");
                txt2_5.setBackground(Color.white);
            }
            case "(2, 6)" -> {
                txt2_6.setText("2");
                txt2_6.setBackground(Color.white);
            }
            case "(3, 1)" -> {
                txt3_1.setText("2");
                txt3_1.setBackground(Color.white);
            }
            case "(3, 2)" -> {
                txt3_2.setText("2");
                txt3_2.setBackground(Color.white);
            }
            case "(3, 3)" -> {
                txt3_3.setText("2");
                txt3_3.setBackground(Color.white);
            }
            case "(3, 4)" -> {
                txt3_4.setText("2");
                txt3_4.setBackground(Color.white);
            }
            case "(3, 5)" -> {
                txt3_5.setText("2");
                txt3_5.setBackground(Color.white);
            }
            case "(3, 6)" -> {
                txt3_6.setText("2");
                txt3_6.setBackground(Color.white);
            }
            case "(4, 1)" -> {
                txt4_1.setText("2");
                txt4_1.setBackground(Color.white);
            }
            case "(4, 2)" -> {
                txt4_2.setText("2");
                txt4_2.setBackground(Color.white);
            }
            case "(4, 3)" -> {
                txt4_3.setText("2");
                txt4_3.setBackground(Color.white);
            }
            case "(4, 4)" -> {
                txt4_4.setText("2");
                txt4_4.setBackground(Color.white);
            }
            case "(4, 5)" -> {
                txt4_5.setText("2");
                txt4_5.setBackground(Color.white);
            }
            case "(4, 6)" -> {
                txt4_6.setText("2");
                txt4_6.setBackground(Color.white);
            }
            case "(5, 1)" -> {
                txt5_1.setText("2");
                txt5_1.setBackground(Color.white);
            }
            case "(5, 2)" -> {
                txt5_2.setText("2");
                txt5_2.setBackground(Color.white);
            }
            case "(5, 3)" -> {
                txt5_3.setText("2");
                txt5_3.setBackground(Color.white);
            }
            case "(5, 4)" -> {
                txt5_4.setText("2");
                txt5_4.setBackground(Color.white);
            }
            case "(5, 5)" -> {
                txt5_5.setText("2");
                txt5_5.setBackground(Color.white);
            }
            case "(5, 6)" -> {
                txt5_6.setText("2");
                txt5_6.setBackground(Color.white);
            }
            case "(6, 1)" -> {
                txt6_1.setText("2");
                txt6_1.setBackground(Color.white);
            }
            case "(6, 2)" -> {
                txt6_2.setText("2");
                txt6_2.setBackground(Color.white);
            }
            case "(6, 3)" -> {
                txt6_3.setText("2");
                txt6_3.setBackground(Color.white);
            }
            case "(6, 4)" -> {
                txt6_4.setText("2");
                txt6_4.setBackground(Color.white);
            }
            case "(6, 5)" -> {
                txt6_5.setText("2");
                txt6_5.setBackground(Color.white);
            }
            case "(6, 6)" -> {
                txt6_6.setText("2");
                txt6_6.setBackground(Color.white);
            }
        }
        Movimiento movimiento = new Movimiento(2, posicion);
        movimientosHechos.agregarMovimiento(movimiento);
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        switch(posicion){
            case "(1, 1)":
            txt1_1.setText("3");
            txt1_1.setBackground(Color.white);
            break;
            case "(1, 2)":
            txt1_2.setText("3");
            txt1_2.setBackground(Color.white);
            break;
            case "(1, 3)":
            txt1_3.setText("3");
            txt1_3.setBackground(Color.white);
            break;
            case "(1, 4)":
            txt1_4.setText("3");
            txt1_4.setBackground(Color.white);
            break;
            case "(1, 5)":
            txt1_5.setText("3");
            txt1_5.setBackground(Color.white);
            break;
            case "(1, 6)":
            txt1_6.setText("3");
            txt1_6.setBackground(Color.white);
            break;
            case "(2, 1)":
            txt2_1.setText("3");
            txt2_1.setBackground(Color.white);
            break;
            case "(2, 2)":
            txt2_2.setText("3");
            txt2_2.setBackground(Color.white);
            break;
            case "(2, 3)":
            txt2_3.setText("3");
            txt2_3.setBackground(Color.white);
            break;
            case "(2, 4)":
            txt2_4.setText("3");
            txt2_4.setBackground(Color.white);
            break;
            case "(2, 5)":
            txt2_5.setText("3");
            txt2_5.setBackground(Color.white);
            break;
            case "(2, 6)":
            txt2_6.setText("3");
            txt2_6.setBackground(Color.white);
            break;
            case "(3, 1)":
            txt3_1.setText("3");
            txt3_1.setBackground(Color.white);
            break;
            case "(3, 2)":
            txt3_2.setText("3");
            txt3_2.setBackground(Color.white);
            break;
            case "(3, 3)":
            txt3_3.setText("3");
            txt3_3.setBackground(Color.white);
            break;
            case "(3, 4)":
            txt3_4.setText("3");
            txt3_4.setBackground(Color.white);
            break;
            case "(3, 5)":
            txt3_5.setText("3");
            txt3_5.setBackground(Color.white);
            break;
            case "(3, 6)":
            txt3_6.setText("3");
            txt3_6.setBackground(Color.white);
            break;
            case "(4, 1)":
            txt4_1.setText("3");
            txt4_1.setBackground(Color.white);
            break;
            case "(4, 2)":
            txt4_2.setText("3");
            txt4_2.setBackground(Color.white);
            break;
            case "(4, 3)":
            txt4_3.setText("3");
            txt4_3.setBackground(Color.white);
            break;
            case "(4, 4)":
            txt4_4.setText("3");
            txt4_4.setBackground(Color.white);
            break;
            case "(4, 5)":
            txt4_5.setText("3");
            txt4_5.setBackground(Color.white);
            break;
            case "(4, 6)":
            txt4_6.setText("3");
            txt4_6.setBackground(Color.white);
            break;
            case "(5, 1)":
            txt5_1.setText("3");
            txt5_1.setBackground(Color.white);
            break;
            case "(5, 2)":
            txt5_2.setText("3");
            txt5_2.setBackground(Color.white);
            break;
            case "(5, 3)":
            txt5_3.setText("3");
            txt5_3.setBackground(Color.white);
            break;
            case "(5, 4)":
            txt5_4.setText("3");
            txt5_4.setBackground(Color.white);
            break;
            case "(5, 5)":
            txt5_5.setText("3");
            txt5_5.setBackground(Color.white);
            break;
            case "(5, 6)":
            txt5_6.setText("3");
            txt5_6.setBackground(Color.white);
            break;
            case "(6, 1)":
            txt6_1.setText("3");
            txt6_1.setBackground(Color.white);
            break;
            case "(6, 2)":
            txt6_2.setText("3");
            txt6_2.setBackground(Color.white);
            break;
            case "(6, 3)":
            txt6_3.setText("3");
            txt6_3.setBackground(Color.white);
            break;
            case "(6, 4)":
            txt6_4.setText("3");
            txt6_4.setBackground(Color.white);
            break;
            case "(6, 5)":
            txt6_5.setText("3");
            txt6_5.setBackground(Color.white);
            break;
            case "(6, 6)":
            txt6_6.setText("3");
            txt6_6.setBackground(Color.white);
            break;
        }
        Movimiento movimiento = new Movimiento(3, posicion);
        movimientosHechos.agregarMovimiento(movimiento);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        switch(posicion){
            case "(1, 1)":
            txt1_1.setText("4");
            txt1_1.setBackground(Color.white);
            break;
            case "(1, 2)":
            txt1_2.setText("4");
            txt1_2.setBackground(Color.white);
            break;
            case "(1, 3)":
            txt1_3.setText("4");
            txt1_3.setBackground(Color.white);
            break;
            case "(1, 4)":
            txt1_4.setText("4");
            txt1_4.setBackground(Color.white);
            break;
            case "(1, 5)":
            txt1_5.setText("4");
            txt1_5.setBackground(Color.white);
            break;
            case "(1, 6)":
            txt1_6.setText("4");
            txt1_6.setBackground(Color.white);
            break;
            case "(2, 1)":
            txt2_1.setText("4");
            txt2_1.setBackground(Color.white);
            break;
            case "(2, 2)":
            txt2_2.setText("4");
            txt2_2.setBackground(Color.white);
            break;
            case "(2, 3)":
            txt2_3.setText("4");
            txt2_3.setBackground(Color.white);
            break;
            case "(2, 4)":
            txt2_4.setText("4");
            txt2_4.setBackground(Color.white);
            break;
            case "(2, 5)":
            txt2_5.setText("4");
            txt2_5.setBackground(Color.white);
            break;
            case "(2, 6)":
            txt2_6.setText("4");
            txt2_6.setBackground(Color.white);
            break;
            case "(3, 1)":
            txt3_1.setText("4");
            txt3_1.setBackground(Color.white);
            break;
            case "(3, 2)":
            txt3_2.setText("4");
            txt3_2.setBackground(Color.white);
            break;
            case "(3, 3)":
            txt3_3.setText("4");
            txt3_3.setBackground(Color.white);
            break;
            case "(3, 4)":
            txt3_4.setText("4");
            txt3_4.setBackground(Color.white);
            break;
            case "(3, 5)":
            txt3_5.setText("4");
            txt3_5.setBackground(Color.white);
            break;
            case "(3, 6)":
            txt3_6.setText("4");
            txt3_6.setBackground(Color.white);
            break;
            case "(4, 1)":
            txt4_1.setText("4");
            txt4_1.setBackground(Color.white);
            break;
            case "(4, 2)":
            txt4_2.setText("4");
            txt4_2.setBackground(Color.white);
            break;
            case "(4, 3)":
            txt4_3.setText("4");
            txt4_3.setBackground(Color.white);
            break;
            case "(4, 4)":
            txt4_4.setText("4");
            txt4_4.setBackground(Color.white);
            break;
            case "(4, 5)":
            txt4_5.setText("4");
            txt4_5.setBackground(Color.white);
            break;
            case "(4, 6)":
            txt4_6.setText("4");
            txt4_6.setBackground(Color.white);
            break;
            case "(5, 1)":
            txt5_1.setText("4");
            txt5_1.setBackground(Color.white);
            break;
            case "(5, 2)":
            txt5_2.setText("4");
            txt5_2.setBackground(Color.white);
            break;
            case "(5, 3)":
            txt5_3.setText("4");
            txt5_3.setBackground(Color.white);
            break;
            case "(5, 4)":
            txt5_4.setText("4");
            txt5_4.setBackground(Color.white);
            break;
            case "(5, 5)":
            txt5_5.setText("4");
            txt5_5.setBackground(Color.white);
            break;
            case "(5, 6)":
            txt5_6.setText("4");
            txt5_6.setBackground(Color.white);
            break;
            case "(6, 1)":
            txt6_1.setText("4");
            txt6_1.setBackground(Color.white);
            break;
            case "(6, 2)":
            txt6_2.setText("4");
            txt6_2.setBackground(Color.white);
            break;
            case "(6, 3)":
            txt6_3.setText("4");
            txt6_3.setBackground(Color.white);
            break;
            case "(6, 4)":
            txt6_4.setText("4");
            txt6_4.setBackground(Color.white);
            break;
            case "(6, 5)":
            txt6_5.setText("4");
            txt6_5.setBackground(Color.white);
            break;
            case "(6, 6)":
            txt6_6.setText("4");
            txt6_6.setBackground(Color.white);
            break;
        }
        Movimiento movimiento = new Movimiento(4, posicion);
        movimientosHechos.agregarMovimiento(movimiento);
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        switch(posicion){
            case "(1, 1)":
            txt1_1.setText("6");
            txt1_1.setBackground(Color.white);
            break;
            case "(1, 2)":
            txt1_2.setText("6");
            txt1_2.setBackground(Color.white);
            break;
            case "(1, 3)":
            txt1_3.setText("6");
            txt1_3.setBackground(Color.white);
            break;
            case "(1, 4)":
            txt1_4.setText("6");
            txt1_4.setBackground(Color.white);
            break;
            case "(1, 5)":
            txt1_5.setText("6");
            txt1_5.setBackground(Color.white);
            break;
            case "(1, 6)":
            txt1_6.setText("6");
            txt1_6.setBackground(Color.white);
            break;
            case "(2, 1)":
            txt2_1.setText("6");
            txt2_1.setBackground(Color.white);
            break;
            case "(2, 2)":
            txt2_2.setText("6");
            txt2_2.setBackground(Color.white);
            break;
            case "(2, 3)":
            txt2_3.setText("6");
            txt2_3.setBackground(Color.white);
            break;
            case "(2, 4)":
            txt2_4.setText("6");
            txt2_4.setBackground(Color.white);
            break;
            case "(2, 5)":
            txt2_5.setText("6");
            txt2_5.setBackground(Color.white);
            break;
            case "(2, 6)":
            txt2_6.setText("6");
            txt2_6.setBackground(Color.white);
            break;
            case "(3, 1)":
            txt3_1.setText("6");
            txt3_1.setBackground(Color.white);
            break;
            case "(3, 2)":
            txt3_2.setText("6");
            txt3_2.setBackground(Color.white);
            break;
            case "(3, 3)":
            txt3_3.setText("6");
            txt3_3.setBackground(Color.white);
            break;
            case "(3, 4)":
            txt3_4.setText("6");
            txt3_4.setBackground(Color.white);
            break;
            case "(3, 5)":
            txt3_5.setText("6");
            txt3_5.setBackground(Color.white);
            break;
            case "(3, 6)":
            txt3_6.setText("6");
            txt3_6.setBackground(Color.white);
            break;
            case "(4, 1)":
            txt4_1.setText("6");
            txt4_1.setBackground(Color.white);
            break;
            case "(4, 2)":
            txt4_2.setText("6");
            txt4_2.setBackground(Color.white);
            break;
            case "(4, 3)":
            txt4_3.setText("6");
            txt4_3.setBackground(Color.white);
            break;
            case "(4, 4)":
            txt4_4.setText("6");
            txt4_4.setBackground(Color.white);
            break;
            case "(4, 5)":
            txt4_5.setText("6");
            txt4_5.setBackground(Color.white);
            break;
            case "(4, 6)":
            txt4_6.setText("6");
            txt4_6.setBackground(Color.white);
            break;
            case "(5, 1)":
            txt5_1.setText("6");
            txt5_1.setBackground(Color.white);
            break;
            case "(5, 2)":
            txt5_2.setText("6");
            txt5_2.setBackground(Color.white);
            break;
            case "(5, 3)":
            txt5_3.setText("6");
            txt5_3.setBackground(Color.white);
            break;
            case "(5, 4)":
            txt5_4.setText("6");
            txt5_4.setBackground(Color.white);
            break;
            case "(5, 5)":
            txt5_5.setText("6");
            txt5_5.setBackground(Color.white);
            break;
            case "(5, 6)":
            txt5_6.setText("6");
            txt5_6.setBackground(Color.white);
            break;
            case "(6, 1)":
            txt6_1.setText("6");
            txt6_1.setBackground(Color.white);
            break;
            case "(6, 2)":
            txt6_2.setText("6");
            txt6_2.setBackground(Color.white);
            break;
            case "(6, 3)":
            txt6_3.setText("6");
            txt6_3.setBackground(Color.white);
            break;
            case "(6, 4)":
            txt6_4.setText("6");
            txt6_4.setBackground(Color.white);
            break;
            case "(6, 5)":
            txt6_5.setText("6");
            txt6_5.setBackground(Color.white);
            break;
            case "(6, 6)":
            txt6_6.setText("6");
            txt6_6.setBackground(Color.white);
            break;
        }
        Movimiento movimiento = new Movimiento(6, posicion);
        movimientosHechos.agregarMovimiento(movimiento);
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
        switch(posicion){
            case "(1, 1)":
            txt1_1.setText("5");
            txt1_1.setBackground(Color.white);
            break;
            case "(1, 2)":
            txt1_2.setText("5");
            txt1_2.setBackground(Color.white);
            break;
            case "(1, 3)":
            txt1_3.setText("5");
            txt1_3.setBackground(Color.white);
            break;
            case "(1, 4)":
            txt1_4.setText("5");
            txt1_4.setBackground(Color.white);
            break;
            case "(1, 5)":
            txt1_5.setText("5");
            txt1_5.setBackground(Color.white);
            break;
            case "(1, 6)":
            txt1_6.setText("5");
            txt1_6.setBackground(Color.white);
            break;
            case "(2, 1)":
            txt2_1.setText("5");
            txt2_1.setBackground(Color.white);
            break;
            case "(2, 2)":
            txt2_2.setText("5");
            txt2_2.setBackground(Color.white);
            break;
            case "(2, 3)":
            txt2_3.setText("5");
            txt2_3.setBackground(Color.white);
            break;
            case "(2, 4)":
            txt2_4.setText("5");
            txt2_4.setBackground(Color.white);
            break;
            case "(2, 5)":
            txt2_5.setText("5");
            txt2_5.setBackground(Color.white);
            break;
            case "(2, 6)":
            txt2_6.setText("5");
            txt2_6.setBackground(Color.white);
            break;
            case "(3, 1)":
            txt3_1.setText("5");
            txt3_1.setBackground(Color.white);
            break;
            case "(3, 2)":
            txt3_2.setText("5");
            txt3_2.setBackground(Color.white);
            break;
            case "(3, 3)":
            txt3_3.setText("5");
            txt3_3.setBackground(Color.white);
            break;
            case "(3, 4)":
            txt3_4.setText("5");
            txt3_4.setBackground(Color.white);
            break;
            case "(3, 5)":
            txt3_5.setText("5");
            txt3_5.setBackground(Color.white);
            break;
            case "(3, 6)":
            txt3_6.setText("5");
            txt3_6.setBackground(Color.white);
            break;
            case "(4, 1)":
            txt4_1.setText("5");
            txt4_1.setBackground(Color.white);
            break;
            case "(4, 2)":
            txt4_2.setText("5");
            txt4_2.setBackground(Color.white);
            break;
            case "(4, 3)":
            txt4_3.setText("5");
            txt4_3.setBackground(Color.white);
            break;
            case "(4, 4)":
            txt4_4.setText("5");
            txt4_4.setBackground(Color.white);
            break;
            case "(4, 5)":
            txt4_5.setText("5");
            txt4_5.setBackground(Color.white);
            break;
            case "(4, 6)":
            txt4_6.setText("5");
            txt4_6.setBackground(Color.white);
            break;
            case "(5, 1)":
            txt5_1.setText("5");
            txt5_1.setBackground(Color.white);
            break;
            case "(5, 2)":
            txt5_2.setText("5");
            txt5_2.setBackground(Color.white);
            break;
            case "(5, 3)":
            txt5_3.setText("5");
            txt5_3.setBackground(Color.white);
            break;
            case "(5, 4)":
            txt5_4.setText("5");
            txt5_4.setBackground(Color.white);
            break;
            case "(5, 5)":
            txt5_5.setText("5");
            txt5_5.setBackground(Color.white);
            break;
            case "(5, 6)":
            txt5_6.setText("5");
            txt5_6.setBackground(Color.white);
            break;
            case "(6, 1)":
            txt6_1.setText("5");
            txt6_1.setBackground(Color.white);
            break;
            case "(6, 2)":
            txt6_2.setText("5");
            txt6_2.setBackground(Color.white);
            break;
            case "(6, 3)":
            txt6_3.setText("5");
            txt6_3.setBackground(Color.white);
            break;
            case "(6, 4)":
            txt6_4.setText("5");
            txt6_4.setBackground(Color.white);
            break;
            case "(6, 5)":
            txt6_5.setText("5");
            txt6_5.setBackground(Color.white);
            break;
            case "(6, 6)":
            txt6_6.setText("5");
            txt6_6.setBackground(Color.white);
            break;
        }
        Movimiento movimiento = new Movimiento(5, posicion);
        movimientosHechos.agregarMovimiento(movimiento);
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
        int indice = movimientosHechos.buscarMovimiento(Integer.parseInt(valorCelda), posicion);
        Movimiento movimientoABorrar = movimientosHechos.getMovimientosHechos().get(indice);
        movimientoABorrar = movimientosHechos.borrarJugada(movimientoABorrar);
        movimientosBorrados.agregarMovimiento(movimientoABorrar);
        switch(posicion){
            case "(1, 1)":
            txt1_1.setText("");
            txt1_1.setBackground(Color.white);
            break;
            case "(1, 2)":
            txt1_2.setText("");
            txt1_2.setBackground(Color.white);
            break;
            case "(1, 3)":
            txt1_3.setText("");
            txt1_3.setBackground(Color.white);
            break;
            case "(1, 4)":
            txt1_4.setText("");
            txt1_4.setBackground(Color.white);
            break;
            case "(1, 5)":
            txt1_5.setText("");
            txt1_5.setBackground(Color.white);
            break;
            case "(1, 6)":
            txt1_6.setText("");
            txt1_6.setBackground(Color.white);
            break;
            case "(2, 1)":
            txt2_1.setText("");
            txt2_1.setBackground(Color.white);
            break;
            case "(2, 2)":
            txt2_2.setText("");
            txt2_2.setBackground(Color.white);
            break;
            case "(2, 3)":
            txt2_3.setText("");
            txt2_3.setBackground(Color.white);
            break;
            case "(2, 4)":
            txt2_4.setText("");
            txt2_4.setBackground(Color.white);
            break;
            case "(2, 5)":
            txt2_5.setText("");
            txt2_5.setBackground(Color.white);
            break;
            case "(2, 6)":
            txt2_6.setText("");
            txt2_6.setBackground(Color.white);
            break;
            case "(3, 1)":
            txt3_1.setText("");
            txt3_1.setBackground(Color.white);
            break;
            case "(3, 2)":
            txt3_2.setText("");
            txt3_2.setBackground(Color.white);
            break;
            case "(3, 3)":
            txt3_3.setText("");
            txt3_3.setBackground(Color.white);
            break;
            case "(3, 4)":
            txt3_4.setText("");
            txt3_4.setBackground(Color.white);
            break;
            case "(3, 5)":
            txt3_5.setText("");
            txt3_5.setBackground(Color.white);
            break;
            case "(3, 6)":
            txt3_6.setText("");
            txt3_6.setBackground(Color.white);
            break;
            case "(4, 1)":
            txt4_1.setText("");
            txt4_1.setBackground(Color.white);
            break;
            case "(4, 2)":
            txt4_2.setText("");
            txt4_2.setBackground(Color.white);
            break;
            case "(4, 3)":
            txt4_3.setText("");
            txt4_3.setBackground(Color.white);
            break;
            case "(4, 4)":
            txt4_4.setText("");
            txt4_4.setBackground(Color.white);
            break;
            case "(4, 5)":
            txt4_5.setText("");
            txt4_5.setBackground(Color.white);
            break;
            case "(4, 6)":
            txt4_6.setText("");
            txt4_6.setBackground(Color.white);
            break;
            case "(5, 1)":
            txt5_1.setText("");
            txt5_1.setBackground(Color.white);
            break;
            case "(5, 2)":
            txt5_2.setText("");
            txt5_2.setBackground(Color.white);
            break;
            case "(5, 3)":
            txt5_3.setText("");
            txt5_3.setBackground(Color.white);
            break;
            case "(5, 4)":
            txt5_4.setText("");
            txt5_4.setBackground(Color.white);
            break;
            case "(5, 5)":
            txt5_5.setText("");
            txt5_5.setBackground(Color.white);
            break;
            case "(5, 6)":
            txt5_6.setText("");
            txt5_6.setBackground(Color.white);
            break;
            case "(6, 1)":
            txt6_1.setText("");
            txt6_1.setBackground(Color.white);
            break;
            case "(6, 2)":
            txt6_2.setText("");
            txt6_2.setBackground(Color.white);
            break;
            case "(6, 3)":
            txt6_3.setText("");
            txt6_3.setBackground(Color.white);
            break;
            case "(6, 4)":
            txt6_4.setText("");
            txt6_4.setBackground(Color.white);
            break;
            case "(6, 5)":
            txt6_5.setText("");
            txt6_5.setBackground(Color.white);
            break;
            case "(6, 6)":
            txt6_6.setText("");
            txt6_6.setBackground(Color.white);
            break;
        }
    }//GEN-LAST:event_jButton14ActionPerformed

    private void txt4_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt4_2MouseClicked
        // TODO add your handling code here:
        txt4_2.setBackground(Color.blue);
        valorCelda = txt4_2.getText();
        posicion = "(4, 2)";
    }//GEN-LAST:event_txt4_2MouseClicked

    private void txt1_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt1_1MouseClicked
        // TODO add your handling code here:
        txt1_1.setBackground(Color.blue);
        valorCelda = txt1_1.getText();
        posicion = "(1, 1)";
    }//GEN-LAST:event_txt1_1MouseClicked

    private void txt6_3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt6_3MouseClicked
        // TODO add your handling code here:
        txt6_3.setBackground(Color.blue);
        valorCelda = txt6_3.getText();
        posicion = "(6, 3)";
    }//GEN-LAST:event_txt6_3MouseClicked

    private void txt1_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt1_2MouseClicked
        // TODO add your handling code here:
        txt1_2.setBackground(Color.blue);
        valorCelda = txt1_2.getText();
        posicion = "(1, 2)";
    }//GEN-LAST:event_txt1_2MouseClicked

    private void txt1_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt1_2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt1_2ActionPerformed

    private void txt4_3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt4_3MouseClicked
        // TODO add your handling code here:
        txt4_3.setBackground(Color.blue);
        valorCelda = txt4_3.getText();
        posicion = "(4, 3)";
    }//GEN-LAST:event_txt4_3MouseClicked

    private void txt1_3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt1_3MouseClicked
        // TODO add your handling code here:
        txt1_3.setBackground(Color.blue);
        valorCelda = txt1_3.getText();
        posicion = "(1, 3)";
    }//GEN-LAST:event_txt1_3MouseClicked

    private void txt6_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt6_1MouseClicked
        // TODO add your handling code here:
        txt6_1.setBackground(Color.blue);
        valorCelda = txt6_1.getText();
        posicion = "(6, 1)";
    }//GEN-LAST:event_txt6_1MouseClicked

    private void txt1_4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt1_4MouseClicked
        // TODO add your handling code here:
        txt1_4.setBackground(Color.blue);
        valorCelda = txt1_4.getText();
        posicion = "(1, 4)";
    }//GEN-LAST:event_txt1_4MouseClicked

    private void txt1_5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt1_5MouseClicked
        // TODO add your handling code here:
        txt1_5.setBackground(Color.blue);
        valorCelda = txt1_5.getText();
        posicion = "(1, 5)";
    }//GEN-LAST:event_txt1_5MouseClicked

    private void txt4_4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt4_4MouseClicked
        // TODO add your handling code here:
        txt4_4.setBackground(Color.blue);
        valorCelda = txt4_4.getText();
        posicion = "(4, 4)";
    }//GEN-LAST:event_txt4_4MouseClicked

    private void txt4_4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt4_4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt4_4ActionPerformed

    private void txt6_5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt6_5MouseClicked
        // TODO add your handling code here:
        txt6_5.setBackground(Color.blue);
        valorCelda = txt6_5.getText();
        posicion = "(6, 5)";
    }//GEN-LAST:event_txt6_5MouseClicked

    private void txt1_6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt1_6MouseClicked
        // TODO add your handling code here:
        txt1_6.setBackground(Color.blue);
        valorCelda = txt1_6.getText();
        posicion = "(1, 6)";
    }//GEN-LAST:event_txt1_6MouseClicked

    private void txt4_5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt4_5MouseClicked
        // TODO add your handling code here:
        txt4_5.setBackground(Color.blue);
        valorCelda = txt4_5.getText();
        posicion = "(4, 5)";
    }//GEN-LAST:event_txt4_5MouseClicked

    private void txt2_1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt2_1MouseClicked
        // TODO add your handling code here:
        txt2_1.setBackground(Color.blue);
        valorCelda = txt2_1.getText();
        posicion = "(2, 1)";
    }//GEN-LAST:event_txt2_1MouseClicked

    private void txt6_6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt6_6MouseClicked
        // TODO add your handling code here:
        txt6_6.setBackground(Color.blue);
        valorCelda = txt6_6.getText();
        posicion = "(6, 6)";
    }//GEN-LAST:event_txt6_6MouseClicked

    private void txt6_6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt6_6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt6_6ActionPerformed

    private void txt2_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt2_2MouseClicked
        // TODO add your handling code here:
        txt2_2.setBackground(Color.blue);
        valorCelda = txt2_2.getText();
        posicion = "(2, 2)";
    }//GEN-LAST:event_txt2_2MouseClicked

    private void txt4_6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt4_6MouseClicked
        // TODO add your handling code here:
        txt4_6.setBackground(Color.blue);
        valorCelda = txt4_6.getText();
        posicion = "(4, 6)";
    }//GEN-LAST:event_txt4_6MouseClicked

    private void txt2_3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt2_3MouseClicked
        // TODO add your handling code here:
        txt2_3.setBackground(Color.blue);
        valorCelda = txt2_3.getText();
        posicion = "(2, 3)";
    }//GEN-LAST:event_txt2_3MouseClicked

    private void txt6_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt6_2MouseClicked
        // TODO add your handling code here:
        txt6_2.setBackground(Color.blue);
        valorCelda = txt6_2.getText();
        posicion = "(6, 2)";
    }//GEN-LAST:event_txt6_2MouseClicked

    private void txt2_4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt2_4MouseClicked
        // TODO add your handling code here:
        txt2_4.setBackground(Color.blue);
        valorCelda = txt2_4.getText();
        posicion = "(2, 4)";
    }//GEN-LAST:event_txt2_4MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        MenuPrincipal newframe = new MenuPrincipal(getMovimientosHechos(), getMovimientosBorrados(), getConfig());
        
        newframe.setVisible(true);

        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        for(Jaula ind: getPartidaElegida().getJaulas()){
            String operacion = ind.getOperacion();
            List<String> posiciones = ind.getJaulas();            
            if(!comprobarJuego(operacion, posiciones)){
                System.out.println("El juego no es valido");
                return;
            }
        }
        System.out.println("Felicidades, termino el juego");
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JuegoIzq.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JuegoIzq.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JuegoIzq.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JuegoIzq.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JTextField lab1_1;
    private javax.swing.JTextField lab1_2;
    private javax.swing.JTextField lab1_3;
    private javax.swing.JTextField lab1_4;
    private javax.swing.JTextField lab1_5;
    private javax.swing.JTextField lab1_6;
    private javax.swing.JTextField lab2_1;
    private javax.swing.JTextField lab2_2;
    private javax.swing.JTextField lab2_3;
    private javax.swing.JTextField lab2_4;
    private javax.swing.JTextField lab2_5;
    private javax.swing.JTextField lab2_6;
    private javax.swing.JTextField lab3_1;
    private javax.swing.JTextField lab3_2;
    private javax.swing.JTextField lab3_3;
    private javax.swing.JTextField lab3_4;
    private javax.swing.JTextField lab3_5;
    private javax.swing.JTextField lab3_6;
    private javax.swing.JTextField lab4_1;
    private javax.swing.JTextField lab4_2;
    private javax.swing.JTextField lab4_3;
    private javax.swing.JTextField lab4_4;
    private javax.swing.JTextField lab4_5;
    private javax.swing.JTextField lab4_6;
    private javax.swing.JTextField lab5_1;
    private javax.swing.JTextField lab5_2;
    private javax.swing.JTextField lab5_3;
    private javax.swing.JTextField lab5_4;
    private javax.swing.JTextField lab5_5;
    private javax.swing.JTextField lab5_6;
    private javax.swing.JTextField lab6_1;
    private javax.swing.JTextField lab6_2;
    private javax.swing.JTextField lab6_3;
    private javax.swing.JTextField lab6_4;
    private javax.swing.JTextField lab6_5;
    private javax.swing.JTextField lab6_6;
    private javax.swing.JTextField txt1_1;
    private javax.swing.JTextField txt1_2;
    private javax.swing.JTextField txt1_3;
    private javax.swing.JTextField txt1_4;
    private javax.swing.JTextField txt1_5;
    private javax.swing.JTextField txt1_6;
    private javax.swing.JTextField txt2_1;
    private javax.swing.JTextField txt2_2;
    private javax.swing.JTextField txt2_3;
    private javax.swing.JTextField txt2_4;
    private javax.swing.JTextField txt2_5;
    private javax.swing.JTextField txt2_6;
    private javax.swing.JTextField txt3_1;
    private javax.swing.JTextField txt3_2;
    private javax.swing.JTextField txt3_3;
    private javax.swing.JTextField txt3_4;
    private javax.swing.JTextField txt3_5;
    private javax.swing.JTextField txt3_6;
    private javax.swing.JTextField txt4_1;
    private javax.swing.JTextField txt4_2;
    private javax.swing.JTextField txt4_3;
    private javax.swing.JTextField txt4_4;
    private javax.swing.JTextField txt4_5;
    private javax.swing.JTextField txt4_6;
    private javax.swing.JTextField txt5_1;
    private javax.swing.JTextField txt5_2;
    private javax.swing.JTextField txt5_3;
    private javax.swing.JTextField txt5_4;
    private javax.swing.JTextField txt5_5;
    private javax.swing.JTextField txt5_6;
    private javax.swing.JTextField txt6_1;
    private javax.swing.JTextField txt6_2;
    private javax.swing.JTextField txt6_3;
    private javax.swing.JTextField txt6_4;
    private javax.swing.JTextField txt6_5;
    private javax.swing.JTextField txt6_6;
    // End of variables declaration//GEN-END:variables
}
